#include <stdio.h>
#include "05_a.h"
#include "05_b.h"

int main(int argc, char const *argv[])
{
    printf("hello world\n");
    return 0;
}
