#pragma once
int num=10;