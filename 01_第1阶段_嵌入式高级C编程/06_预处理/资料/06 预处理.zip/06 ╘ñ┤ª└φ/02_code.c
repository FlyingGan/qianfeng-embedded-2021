#include <stdio.h>
#define PI 3.14
int main(int argc, char const *argv[])
{
    //打印IP的值
    printf("PI = %lf\n", PI);
    return 0;
}
