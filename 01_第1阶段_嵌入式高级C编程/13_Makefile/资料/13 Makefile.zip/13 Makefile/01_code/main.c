#include <stdio.h>
#include "fun.h"
int main(int argc, char const *argv[])
{
    printf("%d\n", my_add(10, 20));
    printf("%d\n", my_sub(10, 20));
    printf("%d\n", my_mul(10, 20));
    printf("%d\n", my_div(10, 20));

    return 0;
}
