#ifndef __FUN_H__
#define __FUN_H__

extern int my_add(int x, int y);
extern int my_sub(int x, int y);
extern int my_mul(int x, int y);
extern int my_div(int x, int y);

#endif